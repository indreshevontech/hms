<?php if (!defined('FW')) die('Forbidden');

$manifest['name']        = __( 'Population Methods', 'fw' );
$manifest['description'] = '';
$manifest['version'] = '1.0.19';

$manifest['github_update'] = 'ThemeFuse/Unyson-PopulationMethods-Extension';
