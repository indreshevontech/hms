<?php if (!defined('FW')) die('Forbidden');

$manifest['name']        = __( 'Population Method - Posts', 'fw' );
$manifest['description'] = __( 'Population Method - Posts', 'fw' );

$manifest['version'] = '1.0.0';

$manifest['display'] = 'slider';