<?php if (!defined('FW')) die('Forbidden');
$options =  array(
	'test1' => array(
		'label' => __('Population Method Categories opt 1', 'fw'),
		'desc'  => __('Option description', 'fw'),
		'type'  => 'text',
		'value' => '',
	),
	'test2' => array(
		'label' => __('Population Method Categories opt 2', 'fw'),
		'desc'  => __('Option description', 'fw'),
		'type'  => 'text',
		'value' => '',
	),
);

