<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
	'subtitle' => array(
		'type'  => 'text',
		'label' => __( 'Subtitle', 'fw' ),
		'value' => '',
		'desc'  => __( 'Choose a subtitle for your slide.', 'fw' )
	)
);

