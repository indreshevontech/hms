<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Slider', 'fw' ),
	'description' => __( 'Add a Slider', 'fw' ),
	'tab'         => __( 'Media Elements', 'fw' ),
);
