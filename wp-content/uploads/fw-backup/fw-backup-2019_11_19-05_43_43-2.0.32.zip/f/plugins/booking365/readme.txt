=== multi Scheduler ===
Contributors: Tarek, Tanzil
Tags: appointment, booking, calendar, wordpress, plugin, reservations,  wordpress appointment plugin, appointment plugin wordpress, reservation plugin wordpress, wordpress appointment booking, appointment schedule, scheduling, wordpress booking plugin, booking appointment, appointment booking
Requires at least: 4.2
Tested up to: 4.2
Stable tag: 4.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Booking365 - Responsive Wordpress Appointment Plugin

== Description ==

Booking365 is a modern appointment wordpress plugin and booking system.This appointment wordpress plugin is usefull for taking appointment and booking information from client.It is 100% user friendly and responsive wordpress booking plugin.This wordpress appointment booking can be used for multi-purpose appointment booking like doctor, patient, official appointment, event booking, appointment schedule, general appointment, fitness center appointment and whatever you want.


== Some Features ==
 1.     Multi Booking System
 2.	Multi Scheduling System
 3.	Modern Reporting System
 4.	Fresh and Clean Code,
 5.	Any Language Supported
 6.	Fully Customizable admin panel
 7.	Make the Design as your Theme
 8.	100% User friendly
 9.	All Browser Supported
 10.    Easy ShortCode System
 11.    Category based service
 12.    Payment gateway

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'multi Scheduler'
3. Activate multi Scheduler from your Plugins page.


= From WordPress.org =

1. Download multi Scheduler.
2. Upload the 'multi Scheduler' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate multi Scheduler from your Plugins page.

== Changelog ==

= 1.0 =
* uploaded version 1.0