(function( $ ) {	
	'use strict';
        $('.button_inner').slimScroll({
           height: '20px',
           size: '3px',           
           color: '#5bbc2e'
        });
        
        $('.date_slote').datepicker({
             dateFormat: 'yy-mm-dd'
        });
})( jQuery );